﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(Ship))]
public class ShipInspector : Editor {
	Ship myTarget;
	int tab;
	int pointsLeft;
	public int tempArmor;
	public int tempAttack;
	public int tempAgility;
	public override void OnInspectorGUI ()
	{
		
		myTarget = (Ship)target;
		tab = GUILayout.Toolbar (tab, new string[] {"Ship", "Crew Members"});
		switch (tab) {
		case 0:
			pointsLeft = 100 - (myTarget.attack + myTarget.agility + myTarget.armor);
			myTarget.armor = EditorGUILayout.IntSlider (new GUIContent ("Armor"), myTarget.armor, 10, 100);
			myTarget.attack = EditorGUILayout.IntSlider (new GUIContent ("Attack"), myTarget.attack, 10, 100);
			myTarget.agility = EditorGUILayout.IntSlider (new GUIContent ("Agility"), myTarget.agility, 10, 100);
			EditorGUILayout.IntField (new GUIContent ("Allocation Points Left"), pointsLeft);
			myTarget.hitPoints = EditorGUILayout.IntField (new GUIContent ("Hit Points"), myTarget.hitPoints);
			if (myTarget.armor + myTarget.attack + myTarget.agility > 100) {

				if (myTarget.armor > myTarget.attack && myTarget.armor > myTarget.agility) {
					myTarget.armor = tempArmor;
				} else if (myTarget.attack > myTarget.armor && myTarget.attack > myTarget.agility) {
					myTarget.attack = tempAttack;
				} else if (myTarget.agility > myTarget.armor && myTarget.agility > myTarget.attack) {
					myTarget.agility = tempAgility;
				}
			} else if (myTarget.armor + myTarget.attack + myTarget.agility <= 100) {
				tempArmor = myTarget.armor;
				tempAttack = myTarget.attack;
				tempAgility = myTarget.agility;
			}
			serializedObject.Update ();
			GUIStyle myStyle = new GUIStyle (GUI.skin.GetStyle ("Label"));
			myStyle.alignment = TextAnchor.MiddleCenter;
			SerializedProperty myElem = serializedObject.FindProperty ("shipGuns");
			EditorGUILayout.PropertyField (myElem, new GUIContent ("Ship Guns", "Example: Helium"), true);
			serializedObject.ApplyModifiedProperties ();

			break;
		case 1:
			serializedObject.Update ();
			GUIStyle myStyle2 = new GUIStyle (GUI.skin.GetStyle ("Label"));
			myStyle2.alignment = TextAnchor.MiddleCenter;
			SerializedProperty myElem2 = serializedObject.FindProperty ("crewMembers");
			EditorGUILayout.PropertyField (myElem2, new GUIContent ("Crew Members", ""), true);
			serializedObject.ApplyModifiedProperties ();
			break;
		}

	}

}